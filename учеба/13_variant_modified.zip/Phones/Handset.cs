using PhoneStationModel;

namespace _13_variant.Phones
{
    public enum HandsetState { Off, Idle, Dialing, Ringing, Talking }

    // Делегат события изменения состояния абонентского устройства.
    public delegate void HandsetStateChangedHandler(object? sender, Handset handset);

    public class Handset
    {
        private static int _nextId = 1;

        // Основные свойства базового класса.
        public int Id { get; } = _nextId++;
        public string Number { get; }
        public HandsetState State { get; protected set; } = HandsetState.Off;
        public bool IsRegistered { get; internal set; }
        public PointF Position { get; set; }

        public event EventHandler<CallEventArgs>? IncomingCall;
        public event EventHandler<CallEventArgs>? OutgoingCall;
        public event EventHandler<CallEventArgs>? CallEnded;
        public event HandsetStateChangedHandler? StateChanged;

        public Handset(string number) => Number = number;

        public virtual void SetState(HandsetState newState)
        {
            if (State == newState) return;
            State = newState;
            StateChanged?.Invoke(this, this);
        }

        public virtual bool CanMakeCall() => IsRegistered && State == HandsetState.Idle;

        public virtual void RaiseIncomingCall(Handset from) => IncomingCall?.Invoke(this, new CallEventArgs(from, this, "Входящий вызов"));
        public virtual void RaiseOutgoingCall(Handset to) => OutgoingCall?.Invoke(this, new CallEventArgs(this, to, "Исходящий вызов"));
        public virtual void RaiseCallEnded(Handset partner) => CallEnded?.Invoke(this, new CallEventArgs(this, partner, "Вызов завершён"));

        public override string ToString() => $"{GetType().Name} {Number} [{State}]";
    }
}
