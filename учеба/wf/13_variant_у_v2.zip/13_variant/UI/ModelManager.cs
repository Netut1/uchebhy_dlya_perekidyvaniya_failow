using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using _13_variant.Phones;

namespace PhoneStationModel
{
    public sealed class AtcNode
    {
        public int Id { get; }
        public PointF Position { get; set; }
        public float VisibilityRadius { get; set; } = 300f;
        public AtcNode(int id, PointF position) { Id = id; Position = position; }
    }

    public sealed class ModelManager
    {
        private sealed class DeviceInfo
        {
            public bool Permanent;
            public double RemainingHours;
            public float Vx, Vy;
        }
        private sealed class RouteReservation
        {
            public List<int> Stations = new();
            public List<(int, int)> Links = new();
        }

        private readonly Random _rand = new();
        private readonly Dictionary<Handset, DeviceInfo> _deviceInfo = new();
        private readonly Dictionary<Call, RouteReservation> _reservations = new();
        private readonly Dictionary<Call, List<int>> _callRoutes = new();
        private readonly Dictionary<int, int> _stationLoads = new();
        private readonly Dictionary<(int, int), int> _linkLoads = new();
        private RectangleF _bounds = new(60, 60, 900, 500);
        private int _nextNumber = 1000000;

        public int StationCapacity { get; private set; } = 4;
        public int LinkCapacity { get; private set; } = 2;
        public BaseStation Station { get; } = new();
        public List<Handset> Handsets { get; } = new();
        public List<Signal> Signals { get; } = new();
        public List<AtcNode> Atcs { get; } = new();
        public bool NeedsRepaint { get; private set; } = true;
        public event EventHandler<Handset>? HandsetAdded;
        public event EventHandler<Handset>? HandsetRemoved;
        public event EventHandler<string>? Log;
        public int PermanentPhones { get; private set; }
        public int PermanentHandsets { get; private set; }
        public int TemporaryDevices => _deviceInfo.Count(kv => !kv.Value.Permanent);

        public ModelManager()
        {
            Station.Router.CallCompleted += (_, call) => ReleaseRoute(call);
            Station.Router.CallFailed += (_, args) => Log?.Invoke(this, args.Message);
        }

        public void Configure(int permanentPhones, int permanentHandsets, int stationCapacity, int linkCapacity, RectangleF bounds)
        {
            PermanentPhones = Math.Max(2, permanentPhones);
            PermanentHandsets = Math.Max(2, permanentHandsets);
            StationCapacity = Math.Max(1, stationCapacity);
            LinkCapacity = Math.Max(1, linkCapacity);
            _bounds = bounds;
            Atcs.Clear();
            // АТС сдвинуты ближе к центру; радиусы перекрываются и покрывают большую часть поля.
            SetAtcGeometry(bounds);
            _stationLoads.Clear(); _linkLoads.Clear();
            for (int i = 0; i < 4; i++) _stationLoads[i] = 0;
            for (int i = 0; i < 4; i++) _linkLoads[NormalizeLink(i, (i + 1) % 4)] = 0;
            MarkDirty();
        }

        private void SetAtcGeometry(RectangleF bounds)
        {
            float xInset = bounds.Width * 0.24f;
            float yInset = bounds.Height * 0.24f;
            AtcNode[] nodes = Atcs.Count == 4 ? Atcs.ToArray() : Array.Empty<AtcNode>();
            PointF[] positions =
            {
                new(bounds.Left + xInset, bounds.Top + yInset),
                new(bounds.Right - xInset, bounds.Top + yInset),
                new(bounds.Right - xInset, bounds.Bottom - yInset),
                new(bounds.Left + xInset, bounds.Bottom - yInset)
            };
            if (nodes.Length == 0)
            {
                for (int i = 0; i < 4; i++) Atcs.Add(new AtcNode(i, positions[i]));
                nodes = Atcs.ToArray();
            }
            float radius = Math.Max(100f, Math.Min(bounds.Width, bounds.Height) * 0.43f);
            for (int i = 0; i < 4; i++)
            {
                nodes[i].Position = positions[i];
                nodes[i].VisibilityRadius = radius;
            }
        }

        public void InitializeDevices()
        {
            for (int i = 0; i < PermanentPhones; i++) AddDevice(isPhone: true, permanent: true);
            for (int i = 0; i < PermanentHandsets; i++) AddDevice(isPhone: false, permanent: true);
        }

        public Handset AddTemporaryPhone() => AddDevice(true, false);
        public Handset AddTemporaryHandset() => AddDevice(false, false);

        private Handset AddDevice(bool isPhone, bool permanent)
        {
            var number = (++_nextNumber).ToString();
            Handset device;
            if (isPhone) device = new Phone(number, "Телефон");
            else
            {
                var wired = new WiredHandset(number, "Абонент");
                wired.LiftHook();
                device = wired;
            }

            var p = FindSpawnPosition();
            device.Position = p;
            try
            {
                Station.Register(device);
            }
            catch (Exception ex)
            {
                Log?.Invoke(this, $"Не удалось зарегистрировать абонента: {ex.Message}");
                return device;
            }

            _deviceInfo[device] = new DeviceInfo
            {
                Permanent = permanent,
                RemainingHours = permanent ? double.PositiveInfinity : 6 + _rand.NextDouble() * 18,
                Vx = (float)(_rand.NextDouble() * 4.0 - 2.0),
                Vy = (float)(_rand.NextDouble() * 4.0 - 2.0)
            };
            Handsets.Add(device);
            HandsetAdded?.Invoke(this, device);
            Log?.Invoke(this, $"Добавлен {(permanent ? "постоянный" : "временный")} {(isPhone ? "телефон" : "трубка")} №{device.Number}" +
                (permanent ? "." : $", срок жизни: {_deviceInfo[device].RemainingHours:F1} виртуальных ч."));
            MarkDirty();
            return device;
        }

        private PointF FindSpawnPosition()
        {
            for (int attempt = 0; attempt < 150; attempt++)
            {
                PointF p;
                if (Atcs.Count == 4)
                {
                    var atc = Atcs[_rand.Next(Atcs.Count)];
                    double angle = _rand.NextDouble() * Math.PI * 2;
                    double radius = _rand.NextDouble() * Math.Max(30, atc.VisibilityRadius - 35);
                    p = new PointF(atc.Position.X + (float)(Math.Cos(angle) * radius), atc.Position.Y + (float)(Math.Sin(angle) * radius));
                    p = new PointF(Math.Clamp(p.X, _bounds.Left + 20, _bounds.Right - 20), Math.Clamp(p.Y, _bounds.Top + 20, _bounds.Bottom - 20));
                }
                else
                {
                    p = new PointF((float)(_bounds.Left + 25 + _rand.NextDouble() * Math.Max(1, _bounds.Width - 50)),
                                   (float)(_bounds.Top + 25 + _rand.NextDouble() * Math.Max(1, _bounds.Height - 50)));
                }
                if (Handsets.All(h => Distance(h.Position, p) >= 38)) return p;
            }
            return new PointF(_bounds.Left + 30, _bounds.Top + 30);
        }

        public void UpdateBounds(RectangleF bounds)
        {
            _bounds = bounds;
            if (Atcs.Count == 4) SetAtcGeometry(bounds);
            MarkDirty();
        }

        public void Tick(double elapsedSeconds, double elapsedVirtualHours)
        {
            foreach (var h in Handsets.ToList())
            {
                if (!_deviceInfo.TryGetValue(h, out var info)) continue;
                if (!info.Permanent)
                {
                    info.RemainingHours -= elapsedVirtualHours;
                    if (info.RemainingHours <= 0)
                    {
                        RemoveDevice(h, "истёк срок жизни");
                        continue;
                    }
                }

                // Случайное блуждание: скорость слегка меняется на каждом тике.
                info.Vx = Math.Clamp(info.Vx + (float)(_rand.NextDouble() - 0.5) * 0.75f, -2.8f, 2.8f);
                info.Vy = Math.Clamp(info.Vy + (float)(_rand.NextDouble() - 0.5) * 0.75f, -2.8f, 2.8f);
                h.Position = new PointF(h.Position.X + info.Vx * (float)(elapsedSeconds * 28),
                                        h.Position.Y + info.Vy * (float)(elapsedSeconds * 28));
                const float pad = 20f;
                if (h.Position.X < _bounds.Left + pad || h.Position.X > _bounds.Right - pad)
                {
                    info.Vx = -info.Vx;
                    h.Position = new PointF(Math.Clamp(h.Position.X, _bounds.Left + pad, _bounds.Right - pad), h.Position.Y);
                }
                if (h.Position.Y < _bounds.Top + pad || h.Position.Y > _bounds.Bottom - pad)
                {
                    info.Vy = -info.Vy;
                    h.Position = new PointF(h.Position.X, Math.Clamp(h.Position.Y, _bounds.Top + pad, _bounds.Bottom - pad));
                }
            }

            UpdateActiveRoutes();

            for (int i = Signals.Count - 1; i >= 0; i--)
            {
                Signals[i].Progress += (float)(elapsedSeconds * 3.0);
                if (Signals[i].Progress >= 1f)
                {
                    var signal = Signals[i];
                    Signals.RemoveAt(i);
                    signal.OnComplete?.Invoke();
                }
            }
            MarkDirty();
        }

        public bool MakeRandomCall()
        {
            var idle = Handsets.Where(h => h.IsRegistered && h.State == HandsetState.Idle && h.CanMakeCall()).ToList();
            if (idle.Count < 2) return false;
            var from = idle[_rand.Next(idle.Count)];
            var candidates = idle.Where(h => h != from).ToList();
            // Сначала выбираем адресата, у которого есть маршрут через доступные АТС.
            foreach (var to in candidates.OrderBy(_ => _rand.Next()))
            {
                var route = FindRoute(from.Position, to.Position);
                if (route == null || !CanReserve(route)) continue;
                if (from is WiredHandset wh && wh.Hook != HookState.OffHook) wh.LiftHook();
                var call = Station.Call(from, to.Number);
                if (call == null) continue;
                Reserve(call, route);
                _callRoutes[call] = route.ToList();
                CreateCallSignals(call, route);
                Log?.Invoke(this, $"Вызов: {from.Number} → {to.Number}; маршрут АТС {string.Join("–", route.Select(i => i + 1))}.");
                MarkDirty();
                return true;
            }
            Log?.Invoke(this, "Вызов не выполнен: нет свободного маршрута или абоненты вне зоны видимости АТС.");
            return false;
        }

        private List<int>? FindRoute(PointF from, PointF to)
        {
            var starts = Atcs.Where(a => Distance(a.Position, from) <= a.VisibilityRadius).Select(a => a.Id).ToList();
            var ends = Atcs.Where(a => Distance(a.Position, to) <= a.VisibilityRadius).Select(a => a.Id).ToList();
            if (starts.Count == 0 || ends.Count == 0) return null;

            var options = new List<List<int>>();
            foreach (int a in starts)
            foreach (int b in ends)
            {
                if (a == b) options.Add(new List<int> { a });
                else
                {
                    var clockwise = new List<int> { a };
                    for (int n = a, guard = 0; n != b && guard < 4; guard++) { n = (n + 1) % 4; clockwise.Add(n); }
                    var counter = new List<int> { a };
                    for (int n = a, guard = 0; n != b && guard < 4; guard++) { n = (n + 3) % 4; counter.Add(n); }
                    options.Add(clockwise);
                    options.Add(counter);
                }
            }
            return options.DistinctBy(r => string.Join(",", r)).OrderBy(r => r.Count).FirstOrDefault(CanReserve);
        }

        private void UpdateActiveRoutes()
        {
            foreach (var call in Station.Router.ActiveCalls.ToList())
            {
                var oldRoute = _callRoutes.TryGetValue(call, out var old) ? old : null;
                if (oldRoute != null && IsRouteStillUsable(call, oldRoute)) continue;

                ReleaseReservationOnly(call);
                var newRoute = FindRoute(call.Caller.Position, call.Callee.Position);
                if (newRoute == null)
                {
                    Station.Router.AbortCall(call);
                    Log?.Invoke(this, $"Звонок {call.Caller.Number} → {call.Callee.Number} прерван: абонент вне покрытия или нет свободного маршрута.");
                    continue;
                }
                Reserve(call, newRoute);
                _callRoutes[call] = newRoute.ToList();
                if (!call.Connection.IsEstablished) CreateCallSignals(call, newRoute);
                Log?.Invoke(this, $"Переключение маршрута звонка {call.Caller.Number} → {call.Callee.Number}: АТС {string.Join("–", newRoute.Select(i => i + 1))}.");
            }
        }

        private bool IsRouteStillUsable(Call call, List<int> route)
        {
            return Distance(call.Caller.Position, Atcs[route[0]].Position) <= Atcs[route[0]].VisibilityRadius
                && Distance(call.Callee.Position, Atcs[route[^1]].Position) <= Atcs[route[^1]].VisibilityRadius;
        }

        private void CreateCallSignals(Call call, List<int> route)
        {
            Signals.RemoveAll(s => s.RelatedCall == call);
            var points = new List<PointF> { call.Caller.Position };
            points.AddRange(route.Select(id => Atcs[id].Position));
            points.Add(call.Callee.Position);
            Color endpointColor = call.Caller is Phone ? Color.DodgerBlue : Color.IndianRed;
            for (int segment = 0; segment < points.Count - 1; segment++)
            {
                PointF a = points[segment], b = points[segment + 1];
                bool isAtcLink = segment > 0 && segment < points.Count - 2;
                PointF mid = new((a.X + b.X) / 2f, (a.Y + b.Y) / 2f);
                Signals.Add(new Signal
                {
                    From = a, Via = mid, To = b,
                    Color = isAtcLink ? Color.LimeGreen : endpointColor,
                    RelatedCall = call,
                    OnComplete = segment == points.Count - 2 ? () => Station.Answer(call.Callee) : null
                });
            }
        }

        private bool CanReserve(List<int> route)
        {
            if (route.Any(id => _stationLoads[id] >= StationCapacity)) return false;
            for (int i = 0; i < route.Count - 1; i++)
                if (_linkLoads[NormalizeLink(route[i], route[i + 1])] >= LinkCapacity) return false;
            return true;
        }

        private void Reserve(Call call, List<int> route)
        {
            var reservation = new RouteReservation { Stations = route.Distinct().ToList() };
            for (int i = 0; i < route.Count - 1; i++) reservation.Links.Add(NormalizeLink(route[i], route[i + 1]));
            foreach (int id in reservation.Stations) _stationLoads[id]++;
            foreach (var link in reservation.Links) _linkLoads[link]++;
            _reservations[call] = reservation;
            _callRoutes[call] = route.ToList();
        }

        private void ReleaseReservationOnly(Call call)
        {
            if (!_reservations.Remove(call, out var r)) return;
            foreach (int id in r.Stations) _stationLoads[id] = Math.Max(0, _stationLoads[id] - 1);
            foreach (var link in r.Links) _linkLoads[link] = Math.Max(0, _linkLoads[link] - 1);
            MarkDirty();
        }

        private void ReleaseRoute(Call call)
        {
            ReleaseReservationOnly(call);
            _callRoutes.Remove(call);
            Signals.RemoveAll(s => s.RelatedCall == call);
            MarkDirty();
        }

        private static (int, int) NormalizeLink(int a, int b) => a < b ? (a, b) : (b, a);
        private static float Distance(PointF a, PointF b) { float x = a.X - b.X, y = a.Y - b.Y; return (float)Math.Sqrt(x * x + y * y); }

        private void RemoveDevice(Handset h, string reason)
        {
            var call = Station.Router.FindCallFor(h);
            if (call != null) Station.Router.AbortCall(call);
            Station.Unregister(h);
            Handsets.Remove(h); _deviceInfo.Remove(h);
            HandsetRemoved?.Invoke(this, h);
            Log?.Invoke(this, $"Абонент №{h.Number} удалён: {reason}.");
            MarkDirty();
        }

        public IEnumerable<Wire> GetWires()
        {
            // Физическая сеть — квадрат без диагоналей.
            for (int i = 0; i < 4; i++)
                yield return new Wire { From = Atcs[i].Position, To = Atcs[(i + 1) % 4].Position, Color = Color.SeaGreen, Thickness = 3f, Kind = WireKind.StationLink };

            foreach (var call in Station.Router.ActiveCalls)
            {
                if (!_callRoutes.TryGetValue(call, out var route) || route.Count == 0) continue;
                Color endpointColor = call.Caller is Phone ? Color.DodgerBlue : Color.IndianRed;
                PointF previous = call.Caller.Position;
                yield return new Wire { From = previous, To = Atcs[route[0]].Position, Color = endpointColor, Thickness = 2.5f, Kind = WireKind.CallRoute };
                for (int i = 0; i < route.Count - 1; i++)
                    yield return new Wire { From = Atcs[route[i]].Position, To = Atcs[route[i + 1]].Position, Color = Color.LimeGreen, Thickness = 3f, Kind = WireKind.CallRoute };
                yield return new Wire { From = Atcs[route[^1]].Position, To = call.Callee.Position, Color = endpointColor, Thickness = 2.5f, Kind = WireKind.CallRoute };
            }
        }

        public int GetStationLoad(int id) => _stationLoads.TryGetValue(id, out int n) ? n : 0;
        public int GetLinkLoad(int a, int b) => _linkLoads.TryGetValue(NormalizeLink(a, b), out int n) ? n : 0;
        public double? GetRemainingHours(Handset h) => _deviceInfo.TryGetValue(h, out var info) && !info.Permanent ? info.RemainingHours : null;
        public bool IsPermanent(Handset h) => _deviceInfo.TryGetValue(h, out var info) && info.Permanent;
        public void MarkDirty() => NeedsRepaint = true;
        public void AfterRepaint() => NeedsRepaint = false;
    }

    public class Signal
    {
        public PointF From { get; set; }
        public PointF Via { get; set; }
        public PointF To { get; set; }
        public float Progress { get; set; }
        public Color Color { get; set; } = Color.DodgerBlue;
        public Call? RelatedCall { get; set; }
        public Action? OnComplete { get; set; }
        public PointF CurrentPosition => Progress < 0.5f ? Lerp(From, Via, Progress * 2f) : Lerp(Via, To, (Progress - 0.5f) * 2f);
        private static PointF Lerp(PointF a, PointF b, float t) => new(a.X + (b.X - a.X) * t, a.Y + (b.Y - a.Y) * t);
    }
}
