using System;

namespace PhoneStationModel
{
    /// <summary>
    /// Виртуальные часы симуляции. Идут быстрее реальных.
    /// TimeFactor() — множитель активности в зависимости от времени суток.
    /// </summary>
    public class SimulationClock
    {
        public TimeSpan SimulatedTime { get; private set; } = TimeSpan.FromHours(8);

        /// <summary>Сколько симулированных минут проходит за 1 реальную секунду.</summary>
        public double MinutesPerSecond { get; set; } = 6.0;

        public int Hour => SimulatedTime.Hours;
        public int Minute => SimulatedTime.Minutes;
        public string TimeString => $"{Hour:D2}:{Minute:D2}";
        public bool IsDay => Hour >= 6 && Hour < 20;

        public void Tick(int elapsedMs, double speedMultiplier = 1.0)
        {
            double simMin = elapsedMs / 1000.0 * MinutesPerSecond * speedMultiplier;
            SimulatedTime = SimulatedTime.Add(TimeSpan.FromMinutes(simMin));
            if (SimulatedTime.TotalHours >= 24)
                SimulatedTime -= TimeSpan.FromHours(24);
        }

        /// <summary>Множитель «жизненной активности» по времени суток.</summary>
        public double TimeFactor()
        {
            int h = Hour;
            if (h >= 9 && h <= 18) return 1.5;   // рабочий день
            if (h >= 19 && h <= 22) return 1.2;  // вечер
            if (h >= 7 && h <= 8) return 1.0;    // утро
            if (h >= 23 || h <= 5) return 0.3;   // ночь
            return 0.7;                          // переходные часы
        }
    }
}
