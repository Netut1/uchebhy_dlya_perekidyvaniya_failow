namespace _13_variant.Phones
{
    public class Phone : Handset
    {
        public string Model { get; set; }
        public int Battery { get; protected set; }

        public Phone(string number, string model, int battery = 100) : base(number)
        {
            Model = model;
            Battery = battery;
        }

        public virtual void ConsumeBattery(int amount = 1)
        {
            Battery = Math.Max(0, Battery - amount);
            if (Battery == 0) SetState(HandsetState.Off);
        }

        public override bool CanMakeCall() => base.CanMakeCall() && Battery > 0;
        public override string ToString() => $"{base.ToString()} | {Model} | {Battery}%";
    }
}
