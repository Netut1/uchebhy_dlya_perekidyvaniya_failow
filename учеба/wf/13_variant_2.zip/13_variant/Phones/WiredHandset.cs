using _13_variant.Phones;

namespace PhoneStationModel
{
    public enum HookState { OnHook, OffHook }

    /// <summary>Квадратный абонентский аппарат с трубкой и рычагом.</summary>
    public class WiredHandset : Handset
    {
        public string Location { get; }
        public HookState Hook { get; private set; } = HookState.OnHook;
        public bool HasMechanicalBell { get; set; } = true;
        public event EventHandler<Handset>? BellRang;
        public event EventHandler<HookState>? HookChanged;

        public WiredHandset(string number, string location) : base(number) => Location = location;
        public void LiftHook()
        {
            if (Hook == HookState.OffHook) return;
            Hook = HookState.OffHook; HookChanged?.Invoke(this, Hook);
        }
        public void PutHook()
        {
            if (Hook == HookState.OnHook) return;
            Hook = HookState.OnHook; HookChanged?.Invoke(this, Hook);
            if (State is HandsetState.Talking or HandsetState.Dialing or HandsetState.Ringing) SetState(HandsetState.Idle);
        }
        public override bool CanMakeCall() => base.CanMakeCall() && Hook == HookState.OffHook;
        public override void RaiseIncomingCall(Handset from)
        {
            if (HasMechanicalBell) BellRang?.Invoke(this, this);
            base.RaiseIncomingCall(from);
        }
    }
}
