namespace PhoneStationModel
{
    public enum SessionState { Created, Dialing, Ringing, Active, Ended, Failed }

    public class CallSession
    {
        public Guid Id { get; } = Guid.NewGuid();
        public SessionState State { get; private set; } = SessionState.Created;
        public DateTime StartedAt { get; private set; }
        public DateTime? EndedAt { get; private set; }
        public TimeSpan Duration => (EndedAt ?? DateTime.Now) - StartedAt;

        public event EventHandler<SessionState>? StateChanged;

        public void Start()
        {
            StartedAt = DateTime.Now;
            Transition(SessionState.Dialing);
        }

        public void MarkRinging() => Transition(SessionState.Ringing);
        public void MarkActive() => Transition(SessionState.Active);
        public void End()
        {
            EndedAt = DateTime.Now;
            Transition(SessionState.Ended);
        }

        private void Transition(SessionState next)
        {
            if (State == next) return;
            State = next;
            StateChanged?.Invoke(this, next);
        }
    }
}
