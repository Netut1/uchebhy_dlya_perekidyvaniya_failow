using _13_variant.Phones;

namespace PhoneStationModel
{
    public class CallConnection
    {
        public Handset Caller { get; }
        public Handset Callee { get; }
        public int SignalQuality { get; set; } = 100;
        public bool IsEstablished { get; private set; }

        public event EventHandler? Established;
        public event EventHandler? Lost;

        public CallConnection(Handset caller, Handset callee)
        {
            Caller = caller;
            Callee = callee;
        }

        public void Establish()
        {
            if (IsEstablished) return;
            IsEstablished = true;
            Established?.Invoke(this, EventArgs.Empty);
        }

        public void Drop()
        {
            if (!IsEstablished) return;
            IsEstablished = false;
            Lost?.Invoke(this, EventArgs.Empty);
        }
    }
}
