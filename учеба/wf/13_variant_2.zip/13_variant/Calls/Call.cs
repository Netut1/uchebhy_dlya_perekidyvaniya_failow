using _13_variant.Phones;

namespace PhoneStationModel
{
    public sealed class Call
    {
        public CallSession Session { get; } = new();
        public CallConnection Connection { get; }
        public Handset Caller => Connection.Caller;
        public Handset Callee => Connection.Callee;

        public Call(Handset caller, Handset callee) => Connection = new CallConnection(caller, callee);
        public void Begin()
        {
            Session.Start(); Caller.RaiseOutgoingCall(Callee); Session.MarkRinging();
            Callee.SetState(HandsetState.Ringing); Callee.RaiseIncomingCall(Caller);
        }
        public void Answer()
        {
            Connection.Establish(); Session.MarkActive();
            Caller.SetState(HandsetState.Talking); Callee.SetState(HandsetState.Talking);
        }
        public void End()
        {
            Connection.Drop(); Session.End(); Caller.RaiseCallEnded(Callee); Callee.RaiseCallEnded(Caller);
            if (Caller.State != HandsetState.Off) Caller.SetState(HandsetState.Idle);
            if (Callee.State != HandsetState.Off) Callee.SetState(HandsetState.Idle);
        }
    }
}
