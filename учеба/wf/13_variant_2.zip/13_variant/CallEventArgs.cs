using _13_variant.Phones;

namespace PhoneStationModel
{
    public class CallEventArgs : EventArgs
    {
        public Handset From { get; }
        public Handset? To { get; }
        public string Message { get; }
        public DateTime Time { get; } = DateTime.Now;

        public CallEventArgs(Handset from, Handset? to, string message)
        {
            From = from;
            To = to;
            Message = message;
        }
    }
}
