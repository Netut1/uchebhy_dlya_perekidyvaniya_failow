using PhoneStationModel;

namespace PhoneStationModel
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            ApplicationConfiguration.Initialize();
            using var settingsForm = new StartupSettingsForm();
            if (settingsForm.ShowDialog() != DialogResult.OK) return;
            Application.Run(new SimulationForm(settingsForm.Settings));
        }
    }
}
