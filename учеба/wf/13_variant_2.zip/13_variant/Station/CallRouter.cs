using _13_variant.Phones;

namespace PhoneStationModel
{
    /// <summary>Маршрутизатор обычных абонентских вызовов. Межгорода в этой модели нет.</summary>
    public sealed class CallRouter
    {
        private readonly RegistrationService _registry;
        private readonly Dictionary<Handset, Call> _active = new();
        private readonly List<Call> _history = new();
        public event EventHandler<Call>? CallStarted;
        public event EventHandler<Call>? CallCompleted;
        public event EventHandler<CallEventArgs>? CallFailed;

        public CallRouter(RegistrationService registry) => _registry = registry;
        public IReadOnlyList<Call> ActiveCalls => _active.Values.Distinct().ToList();
        public Call? FindCallFor(Handset h) => _active.TryGetValue(h, out var call) ? call : null;

        public Call? Route(Handset from, string targetNumber)
        {
            if (!_registry.IsRegistered(from) || !from.CanMakeCall())
            {
                Fail(from, null, "Вызывающий абонент не зарегистрирован или не готов к звонку.");
                return null;
            }
            var to = _registry.Find(targetNumber);
            if (to == null) { Fail(from, null, $"Абонент {targetNumber} не найден."); return null; }
            if (ReferenceEquals(from, to)) { Fail(from, to, "Нельзя позвонить самому себе."); return null; }
            if (_active.ContainsKey(from) || _active.ContainsKey(to) || to.State != HandsetState.Idle)
            {
                Fail(from, to, "Один из абонентов уже занят.");
                return null;
            }

            var call = new Call(from, to);
            _active[from] = call; _active[to] = call; _history.Add(call);
            from.SetState(HandsetState.Dialing);
            call.Begin();
            CallStarted?.Invoke(this, call);
            return call;
        }

        public void AnswerCall(Handset who)
        {
            if (_active.TryGetValue(who, out var call) && !call.Connection.IsEstablished) call.Answer();
        }
        public void EndCall(Handset who) { if (_active.TryGetValue(who, out var call)) AbortCall(call); }

        public bool AbortCall(Call call)
        {
            if (!_active.ContainsKey(call.Caller)) return false;
            _active.Remove(call.Caller); _active.Remove(call.Callee);
            call.End(); CallCompleted?.Invoke(this, call); return true;
        }
        public bool AbortLast()
        {
            var call = _history.LastOrDefault(c => _active.ContainsKey(c.Caller));
            return call != null && AbortCall(call);
        }
        public int AbortAll()
        {
            var calls = ActiveCalls.ToList();
            foreach (var call in calls) AbortCall(call);
            return calls.Count;
        }
        private void Fail(Handset from, Handset? to, string message) => CallFailed?.Invoke(this, new CallEventArgs(from, to, message));
    }
}
