using _13_variant.Phones;

namespace PhoneStationModel
{
    public class BaseStation
    {
        public RegistrationService Registration { get; } = new();
        public CallRouter Router { get; }

        public BaseStation() => Router = new CallRouter(Registration);

        public void Register(Handset h) => Registration.Register(h);
        public void Unregister(Handset h) => Registration.Unregister(h);
        public Call? Call(Handset from, string number) => Router.Route(from, number);
        public void Answer(Handset h) => Router.AnswerCall(h);
        public void HangUp(Handset h) => Router.EndCall(h);
    }
}
