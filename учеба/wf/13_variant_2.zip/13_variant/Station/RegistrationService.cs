using _13_variant.Phones;

namespace PhoneStationModel
{
    public class RegistrationService
    {
        private readonly Dictionary<string, Handset> _byNumber = new();
        private readonly List<Handset> _all = new();

        public event EventHandler<Handset>? Registered;
        public event EventHandler<Handset>? Unregistered;

        public IReadOnlyList<Handset> All => _all.AsReadOnly();

        public void Register(Handset h)
        {
            if (_byNumber.ContainsKey(h.Number)) throw new InvalidOperationException($"Номер {h.Number} занят.");
            _byNumber[h.Number] = h;
            _all.Add(h);
            h.IsRegistered = true;
            h.SetState(HandsetState.Idle);
            Registered?.Invoke(this, h);
        }

        public void Unregister(Handset h)
        {
            if (!_byNumber.Remove(h.Number)) return;
            _all.Remove(h);
            h.IsRegistered = false;
            h.SetState(HandsetState.Off);
            Unregistered?.Invoke(this, h);
        }

        public Handset? Find(string number) => _byNumber.TryGetValue(number, out var h) ? h : null;
        public bool IsRegistered(Handset h) => _byNumber.ContainsKey(h.Number);
    }
}
