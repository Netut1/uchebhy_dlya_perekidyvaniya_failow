using System.Drawing;
using System.Windows.Forms;

namespace PhoneStationModel
{
    public sealed class SimulationSettings
    {
        public int Phones { get; set; } = 4;
        public int Handsets { get; set; } = 4;
        public int AtcCapacity { get; set; } = 4;
        public int LinkCapacity { get; set; } = 2;
    }

    public sealed class StartupSettingsForm : Form
    {
        private readonly NumericUpDown _phones = MakeNumber(4, 2, 100);
        private readonly NumericUpDown _handsets = MakeNumber(4, 2, 100);
        private readonly NumericUpDown _atcCapacity = MakeNumber(4, 1, 100);
        private readonly NumericUpDown _linkCapacity = MakeNumber(2, 1, 100);
        public SimulationSettings Settings { get; private set; } = new();

        public StartupSettingsForm()
        {
            Text = "Настройки симуляции";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterScreen;
            MaximizeBox = false; MinimizeBox = false;
            ClientSize = new Size(390, 250);

            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(14), ColumnCount = 2, RowCount = 5 };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 68));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 32));
            AddRow(layout, 0, "Постоянных телефонов (круглые):", _phones);
            AddRow(layout, 1, "Постоянных трубок (квадратные):", _handsets);
            AddRow(layout, 2, "Каналoв на одну АТС:", _atcCapacity);
            AddRow(layout, 3, "Каналов на связь между АТС:", _linkCapacity);
            var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
            var start = new Button { Text = "Начать", DialogResult = DialogResult.OK, Width = 90 };
            var cancel = new Button { Text = "Выход", DialogResult = DialogResult.Cancel, Width = 90 };
            buttons.Controls.Add(start); buttons.Controls.Add(cancel);
            layout.Controls.Add(buttons, 0, 4); layout.SetColumnSpan(buttons, 2);
            Controls.Add(layout);
            AcceptButton = start; CancelButton = cancel;
            start.Click += (_, _) => Settings = new SimulationSettings
            {
                Phones = (int)_phones.Value, Handsets = (int)_handsets.Value,
                AtcCapacity = (int)_atcCapacity.Value, LinkCapacity = (int)_linkCapacity.Value
            };
        }

        private static NumericUpDown MakeNumber(int value, int min, int max) => new()
        {
            Minimum = min, Maximum = max, Value = value, Dock = DockStyle.Fill,
            TextAlign = HorizontalAlignment.Center, ThousandsSeparator = false
        };

        private static void AddRow(TableLayoutPanel layout, int row, string text, Control control)
        {
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            layout.Controls.Add(new Label { Text = text, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, row);
            layout.Controls.Add(control, 1, row);
        }
    }
}
