namespace PhoneStationModel
{
    public enum WireKind { StationLink, CallRoute, DirectTalk }

    public class Wire
    {
        public PointF From { get; set; }
        public PointF To { get; set; }
        public Color Color { get; set; }
        public float Thickness { get; set; } = 2f;
        public WireKind Kind { get; set; }
    }
}
