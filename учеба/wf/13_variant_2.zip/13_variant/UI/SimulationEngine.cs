namespace PhoneStationModel
{
    /// <summary>Управляет виртуальными часами и случайными попытками вызовов. Новые устройства автоматически не создаются.</summary>
    public sealed class SimulationEngine
    {
        private readonly ModelManager _model;
        private readonly Random _random = new();
        private double _callAccumulator;
        public SimulationClock Clock { get; } = new();
        public bool Enabled { get; set; }
        public double SpeedMultiplier { get; set; } = 1.0;
        public double CallsPerVirtualHour { get; set; } = 3.0;
        public event EventHandler<string>? SimulationLog;
        public event EventHandler? StatsChanged;
        public int TotalCallsInitiated { get; private set; }
        public SimulationEngine(ModelManager model) => _model = model;

        public void Tick(int elapsedMs)
        {
            double virtualHours = elapsedMs / 1000.0 * Clock.MinutesPerSecond * SpeedMultiplier / 60.0;
            Clock.Tick(elapsedMs, SpeedMultiplier);
            _model.Tick(elapsedMs / 1000.0, virtualHours);
            if (Enabled)
            {
                _callAccumulator += virtualHours * CallsPerVirtualHour * Clock.TimeFactor();
                while (_callAccumulator >= 1.0)
                {
                    _callAccumulator -= 1.0;
                    if (_model.MakeRandomCall()) TotalCallsInitiated++;
                }
            }
            StatsChanged?.Invoke(this, EventArgs.Empty);
        }
        public void ResetStats() { TotalCallsInitiated = 0; StatsChanged?.Invoke(this, EventArgs.Empty); }
    }
}
