using _13_variant.Phones;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace PhoneStationModel
{
    public sealed class SimulationForm : Form
    {
        private readonly ModelManager _model = new();
        private readonly SimulationEngine _engine;
        private readonly Timer _timer = new() { Interval = 50 };
        private BufferedPanel _field = null!;
        private Button _autoButton = null!;
        private Button _stopButton = null!;
        private Label _status = null!;
        private readonly Font _deviceFont = new("Consolas", 8, FontStyle.Bold);
        private readonly Font _atcFont = new("Arial", 10, FontStyle.Bold);
        private readonly Font _statusFont = new("Consolas", 9, FontStyle.Bold);

        public SimulationForm(SimulationSettings settings)
        {
            Text = "Симуляция сети АТС";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1200, 850);
            MinimumSize = new Size(850, 650);
            _engine = new SimulationEngine(_model);
            BuildUi();
            _model.Configure(settings.Phones, settings.Handsets, settings.AtcCapacity, settings.LinkCapacity, DrawBounds());
            _model.InitializeDevices();
            _model.Log += (_, message) => { _status.Text = message; };
            _model.HandsetAdded += (_, _) => UpdateStatus();
            _model.HandsetRemoved += (_, _) => UpdateStatus();
            _engine.StatsChanged += (_, _) => UpdateStatus();
            _field.Resize += (_, _) => { _model.UpdateBounds(DrawBounds()); _field.Invalidate(); };
            _timer.Tick += (_, _) =>
            {
                _engine.Tick(_timer.Interval);
                if (_model.NeedsRepaint) { _field.Invalidate(); _model.AfterRepaint(); }
                UpdateStatus();
            };
            _timer.Start();
            UpdateStatus();
        }

        private RectangleF DrawBounds() => new(25, 25, Math.Max(300, _field.Width - 50), Math.Max(300, _field.Height - 50));

        private void BuildUi()
        {
            var toolbar = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 52, Padding = new Padding(8), WrapContents = false, BackColor = Color.FromArgb(232, 235, 240) };
            _autoButton = new Button { Text = "Автосимуляция", Width = 145, Height = 34 };
            _stopButton = new Button { Text = "Стоп", Width = 90, Height = 34, Enabled = false };
            var addPhone = new Button { Text = "Добавить телефон", Width = 150, Height = 34 };
            var addHandset = new Button { Text = "Добавить трубку", Width = 150, Height = 34 };
            _autoButton.Click += (_, _) => { _engine.Enabled = true; _autoButton.Enabled = false; _stopButton.Enabled = true; _model.MarkDirty(); UpdateStatus(); };
            _stopButton.Click += (_, _) => { _engine.Enabled = false; _autoButton.Enabled = true; _stopButton.Enabled = false; UpdateStatus(); };
            addPhone.Click += (_, _) => _model.AddTemporaryPhone();
            addHandset.Click += (_, _) => _model.AddTemporaryHandset();
            toolbar.Controls.AddRange(new Control[] { _autoButton, _stopButton, addPhone, addHandset });

            _field = new BufferedPanel { Dock = DockStyle.Fill, BackColor = Color.LightSkyBlue };
            _field.Paint += DrawField;
            _status = new Label { Dock = DockStyle.Bottom, Height = 28, Padding = new Padding(8, 0, 0, 0), TextAlign = ContentAlignment.MiddleLeft, Font = _statusFont, BackColor = Color.FromArgb(225, 228, 235) };
            Controls.Add(_field); Controls.Add(_status); Controls.Add(toolbar);
        }

        private void DrawField(object? sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            int hour = _engine.Clock.Hour;
            Color sky = hour switch { >= 6 and < 9 => Color.FromArgb(255, 205, 155), >= 9 and < 18 => Color.LightSkyBlue, >= 18 and < 21 => Color.FromArgb(240, 150, 110), _ => Color.FromArgb(24, 30, 62) };
            using (var b = new SolidBrush(sky)) g.FillRectangle(b, _field.ClientRectangle);
            var bounds = DrawBounds();
            using (var p = new Pen(Color.FromArgb(45, Color.Black)))
            {
                for (float x = bounds.Left; x <= bounds.Right; x += 50) g.DrawLine(p, x, bounds.Top, x, bounds.Bottom);
                for (float y = bounds.Top; y <= bounds.Bottom; y += 50) g.DrawLine(p, bounds.Left, y, bounds.Right, y);
            }

            // Зелёные линии — только рёбра квадратной сети, никаких диагоналей.
            foreach (var wire in _model.GetWires())
            {
                using var pen = new Pen(wire.Color, wire.Thickness);
                g.DrawLine(pen, wire.From, wire.To);
            }
            for (int i = 0; i < _model.Atcs.Count; i++)
            {
                var a = _model.Atcs[i].Position;
                var b = _model.Atcs[(i + 1) % _model.Atcs.Count].Position;
                string load = $"{_model.GetLinkLoad(i, (i + 1) % 4)}/{_model.LinkCapacity}";
                g.DrawString(load, _deviceFont, Brushes.DarkGreen, (a.X + b.X) / 2f, (a.Y + b.Y) / 2f);
            }

            foreach (var atc in _model.Atcs)
            {
                using var radiusPen = new Pen(Color.FromArgb(65, Color.DarkSlateGray), 1.5f) { DashStyle = DashStyle.Dash };
                float r = atc.VisibilityRadius;
                g.DrawEllipse(radiusPen, atc.Position.X - r, atc.Position.Y - r, r * 2, r * 2);
                var rect = new RectangleF(atc.Position.X - 19, atc.Position.Y - 19, 38, 38);
                g.FillRectangle(Brushes.DarkSlateGray, rect); g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);
                string label = $"АТС {atc.Id + 1}";
                var size = g.MeasureString(label, _atcFont);
                g.DrawString(label, _atcFont, Brushes.White, atc.Position.X - size.Width / 2, atc.Position.Y - 8);
                string cap = $"{_model.GetStationLoad(atc.Id)}/{_model.StationCapacity}";
                g.DrawString(cap, _deviceFont, Brushes.White, atc.Position.X - 15, atc.Position.Y + 22);
            }

            foreach (var h in _model.Handsets)
            {
                Color c = h.State switch { HandsetState.Idle => Color.LightGreen, HandsetState.Dialing => Color.Orange, HandsetState.Ringing => Color.Gold, HandsetState.Talking => Color.Tomato, _ => Color.LightGray };
                using var brush = new SolidBrush(c);
                const float size = 28;
                if (h is Phone) g.FillEllipse(brush, h.Position.X - size / 2, h.Position.Y - size / 2, size, size);
                else g.FillRectangle(brush, h.Position.X - size / 2, h.Position.Y - size / 2, size, size);
                if (h is Phone) g.DrawEllipse(Pens.Black, h.Position.X - size / 2, h.Position.Y - size / 2, size, size);
                else g.DrawRectangle(Pens.Black, h.Position.X - size / 2, h.Position.Y - size / 2, size, size);
                g.DrawString(h.Number, _deviceFont, Brushes.Black, h.Position.X - 18, h.Position.Y + 17);
                var remaining = _model.GetRemainingHours(h);
                if (remaining.HasValue) g.DrawString($"{remaining.Value:F0}ч", _deviceFont, Brushes.DarkRed, h.Position.X - 12, h.Position.Y - 27);
            }

            foreach (var signal in _model.Signals)
            {
                var p = signal.CurrentPosition;
                using var b = new SolidBrush(signal.Color);
                g.FillEllipse(b, p.X - 5, p.Y - 5, 10, 10);
            }

            var time = _engine.Clock.TimeString;
            using var timeFont = new Font("Consolas", 15, FontStyle.Bold);
            using var timeBrush = new SolidBrush(hour >= 6 && hour < 20 ? Color.Black : Color.White);
            g.DrawString(time, timeFont, timeBrush, _field.Width - 90, 12);
        }

        private void UpdateStatus()
        {
            if (_status == null || _status.IsDisposed) return;
            _status.Text = $"Состояние: {(_engine.Enabled ? "автосимуляция" : "остановлена")} | Абонентов: {_model.Handsets.Count} | Временных: {_model.TemporaryDevices} | Активных вызовов: {_model.Station.Router.ActiveCalls.Count} | Вызовов запущено: {_engine.TotalCallsInitiated} | Виртуальное время: {_engine.Clock.TimeString}";
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) { _timer.Dispose(); _deviceFont.Dispose(); _atcFont.Dispose(); _statusFont.Dispose(); }
            base.Dispose(disposing);
        }
    }
}
